using UnityEngine;

public class CardInstance
{
    public CardDefinitionInline.Spec def;
    public int health;
    public Side side;
    public bool alive => health > 0;

    public CardInstance(CardDefinitionInline.Spec def, System.Random rng)
    {
        this.def = def;
        this.health = def.maxHealth;
        this.side = rng.NextDouble() < 0.5 ? Side.Fronte : Side.Retro;
    }

    public void Flip()
    {
        side = side == Side.Fronte ? Side.Retro : Side.Fronte;
    }

    public override string ToString()
    {
        return $"{def.cardName} ({def.faction}) {side} HP:{health}";
    }
}
