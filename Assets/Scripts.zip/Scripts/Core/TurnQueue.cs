// TurnQueue.cs
using System;
using System.Collections.Generic;

public class TurnQueue
{
    public enum ItemState { Enqueued, Executing, Done, Cancelled }

    public struct Item
    {
        public int seq;
        public GameEventType type;
        public EventContext ctx;
        public DateTime time;
        public string note;
        public ItemState state;
        public string producer;   // chi ha enqueued (es. "OnFlipDealDamage#12")
        public string consumer;   // chi lo sta eseguendo
    }

    readonly Queue<Item> _queue = new Queue<Item>();
    int _nextSeq = 1;
    public readonly List<Item> history = new List<Item>();

    public Item Enqueue(GameEventType t, EventContext ctx, string note, string producer = null)
    {
        var it = new Item
        {
            seq = _nextSeq++,
            type = t,
            ctx = ctx,
            time = DateTime.Now,
            note = note,
            state = ItemState.Enqueued,
            producer = producer
        };
        _queue.Enqueue(it);
        history.Add(it);
        return it;
    }

    public bool TryDequeue(out Item it)
    {
        if (_queue.Count > 0)
        {
            it = _queue.Dequeue();
            // aggiorna history allo stesso riferimento
            for (int i = history.Count - 1; i >= 0; --i)
                if (history[i].seq == it.seq) { it.state = ItemState.Executing; history[i] = it; break; }
            return true;
        }
        it = default; return false;
    }

    public void MarkDone(int seq, string consumer = null)
    {
        for (int i = history.Count - 1; i >= 0; --i)
            if (history[i].seq == seq)
            {
                var it = history[i];
                it.state = ItemState.Done;
                if (!string.IsNullOrEmpty(consumer)) it.consumer = consumer;
                history[i] = it;
                break;
            }
    }

    public void Clear() { _queue.Clear(); history.Clear(); _nextSeq = 1; }
    public int Count => _queue.Count;
}
