using UnityEngine;

public enum Faction { Sangue, Ombra, Fiamma }
public enum Side { Fronte, Retro }
public enum FrontType { Attacco, Blocco }

