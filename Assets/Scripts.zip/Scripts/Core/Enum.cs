using UnityEngine;

public enum Faction { A, B, C }
public enum Side { Fronte, Retro }

